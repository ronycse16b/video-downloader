const QUALITIES = ["Best (Video + Audio)", "1080p", "720p", "480p", "360p", "Audio only (MP3)"];
const $ = (id) => document.getElementById(id);
let tab = null;

QUALITIES.forEach((q) => {
  const o = document.createElement("option");
  o.value = q; o.textContent = q;
  $("q").appendChild(o);
});

chrome.storage.local.get({ quality: QUALITIES[0] }, (s) => { $("q").value = s.quality; });
$("q").addEventListener("change", () => chrome.storage.local.set({ quality: $("q").value }));

chrome.runtime.sendMessage({ type: "status" }, (res) => {
  const el = $("status");
  if (res && res.running) {
    el.textContent = "✔ Video Downloader app chalu ache";
    el.className = "status on";
  } else {
    el.textContent = "App bondho — download dile app nijei khulbe";
    el.className = "status off";
  }
});

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  tab = tabs[0];
  const ok = tab && /^https?:\/\//i.test(tab.url || "");
  $("url").textContent = ok ? tab.url : "Ei page theke download kora jabe na";
  $("dl").disabled = !ok;
});

$("dl").addEventListener("click", () => {
  if (!tab) return;
  $("dl").disabled = true;
  $("msg").textContent = "Pathano hocche...";
  chrome.runtime.sendMessage({ type: "download", url: tab.url, quality: $("q").value, tabId: tab.id }, (res) => {
    $("dl").disabled = false;
    if (res && res.ok) {
      $("msg").textContent = res.launched ? "App khulche, download shuru hobe ✔" : "App-e download shuru hoyeche ✔";
      setTimeout(() => window.close(), 1200);
    } else {
      $("msg").textContent = (res && res.error) || "Hoyni, app khule abar chesta korun";
    }
  });
});
