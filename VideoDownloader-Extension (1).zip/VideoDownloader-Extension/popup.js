const QUALITIES = ["Best (Video + Audio)", "1080p", "720p", "480p", "360p", "Audio only (MP3)"];
const $ = (id) => document.getElementById(id);
let tab = null;

QUALITIES.forEach((q) => {
  const o = document.createElement("option");
  o.value = q; o.textContent = q;
  $("q").appendChild(o);
});

chrome.storage.local.get({ quality: QUALITIES[0], catchDownloads: true }, (s) => { $("q").value = s.quality; $("catch").checked = s.catchDownloads; });
$("q").addEventListener("change", () => chrome.storage.local.set({ quality: $("q").value }));
$("catch").addEventListener("change", () => chrome.storage.local.set({ catchDownloads: $("catch").checked }));

chrome.runtime.sendMessage({ type: "status" }, (res) => {
  const el = $("status");
  if (res && res.running) {
    el.textContent = "✔ Video Downloader is running";
    el.className = "status on";
  } else {
    el.textContent = "The app is closed — it will open automatically";
    el.className = "status off";
  }
});

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  tab = tabs[0];
  const ok = tab && /^https?:\/\//i.test(tab.url || "");
  $("url").textContent = ok ? tab.url : "Nothing to download on this page";
  $("dl").disabled = !ok;
});

$("dl").addEventListener("click", () => {
  if (!tab) return;
  $("dl").disabled = true;
  $("msg").textContent = "Sending...";
  chrome.runtime.sendMessage({ type: "download", url: tab.url, quality: $("q").value, tabId: tab.id }, (res) => {
    $("dl").disabled = false;
    if (res && res.ok) {
      $("msg").textContent = res.launched ? "Opening Video Downloader... ✔" : "Download started ✔";
      setTimeout(() => window.close(), 1200);
    } else {
      $("msg").textContent = (res && res.error) || "Failed — open the app and try again";
    }
  });
});
