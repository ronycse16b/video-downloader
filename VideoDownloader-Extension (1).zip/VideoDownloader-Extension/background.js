// Video Downloader extension - app-e link pathay
const API = "http://127.0.0.1:47321";
const QUALITIES = ["Best (Video + Audio)", "1080p", "720p", "480p", "360p", "Audio only (MP3)"];

async function appRunning() {
  try {
    const r = await fetch(API + "/ping", { cache: "no-store" });
    const j = await r.json();
    return j.app === "VideoDownloader";
  } catch (e) {
    return false;
  }
}

// App khola thakle shorashori pathay; bondho thakle vdlapp:// diye app chalu kore
async function sendToApp(url, quality, tabId) {
  if (!/^https?:\/\//i.test(url || "")) return { ok: false, error: "Valid video link paoa jayni" };
  try {
    const r = await fetch(API + "/add", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-VDL": "1" },
      body: JSON.stringify({ url, quality: quality || "" })
    });
    if (r.ok) return { ok: true };
    const j = await r.json().catch(() => ({}));
    return { ok: false, error: j.error || "App link nite pareni" };
  } catch (e) {
    // app bondho
    const proto = "vdlapp://add?url=" + encodeURIComponent(url) + "&q=" + encodeURIComponent(quality || "");
    try {
      if (tabId !== undefined && tabId >= 0) await chrome.tabs.update(tabId, { url: proto });
      else await chrome.tabs.create({ url: proto });
      return { ok: true, launched: true };
    } catch (e2) {
      return { ok: false, error: "Video Downloader app khulun, tarpor abar chesta korun" };
    }
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "vdl-root",
      title: "Video Downloader diye download",
      contexts: ["page", "link", "video", "audio"]
    });
    QUALITIES.forEach((q, i) => {
      chrome.contextMenus.create({ id: "vdl-q-" + i, parentId: "vdl-root", title: q, contexts: ["page", "link", "video", "audio"] });
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const m = /^vdl-q-(\d+)$/.exec(info.menuItemId);
  if (!m) return;
  const quality = QUALITIES[Number(m[1])];
  let url = info.pageUrl;
  if (info.linkUrl) url = info.linkUrl;
  else if (info.srcUrl && /^https?:/i.test(info.srcUrl)) url = info.srcUrl;
  sendToApp(url, quality, tab ? tab.id : undefined);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "download") {
    const tabId = sender.tab ? sender.tab.id : msg.tabId;
    sendToApp(msg.url, msg.quality, tabId).then(sendResponse);
    return true;
  }
  if (msg && msg.type === "status") {
    appRunning().then((running) => sendResponse({ running }));
    return true;
  }
});
