// Video Downloader extension - sends links to the desktop app
const API = "http://127.0.0.1:47321";
const QUALITIES = ["Best (Video + Audio)", "1080p", "720p", "480p", "360p", "Audio only (MP3)"];

async function appRunning() {
  try {
    const r = await fetch(API + "/ping", { cache: "no-store" });
    const j = await r.json();
    return j.app === "VideoDownloader";
  } catch (e) {
    return false;
  }
}

// Send straight to the running app; if it is closed, start it through vdlapp://
async function sendToApp(url, quality, tabId) {
  if (!/^https?:\/\//i.test(url || "")) return { ok: false, error: "No valid video link found" };
  try {
    const r = await fetch(API + "/add", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-VDL": "1" },
      body: JSON.stringify({ url, quality: quality || "" })
    });
    if (r.ok) return { ok: true };
    const j = await r.json().catch(() => ({}));
    return { ok: false, error: j.error || "The app could not accept the link" };
  } catch (e) {
    // app is not running
    const proto = "vdlapp://add?url=" + encodeURIComponent(url) + "&q=" + encodeURIComponent(quality || "");
    try {
      if (tabId !== undefined && tabId >= 0) await chrome.tabs.update(tabId, { url: proto });
      else await chrome.tabs.create({ url: proto });
      return { ok: true, launched: true };
    } catch (e2) {
      return { ok: false, error: "Please open Video Downloader and try again" };
    }
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "vdl-root",
      title: "Download with Video Downloader",
      contexts: ["page", "link", "video", "audio"]
    });
    QUALITIES.forEach((q, i) => {
      chrome.contextMenus.create({ id: "vdl-q-" + i, parentId: "vdl-root", title: q, contexts: ["page", "link", "video", "audio"] });
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const m = /^vdl-q-(\d+)$/.exec(info.menuItemId);
  if (!m) return;
  const quality = QUALITIES[Number(m[1])];
  let url = info.pageUrl;
  if (info.linkUrl) url = info.linkUrl;
  else if (info.srcUrl && /^https?:/i.test(info.srcUrl)) url = info.srcUrl;
  sendToApp(url, quality, tab ? tab.id : undefined);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "download") {
    const tabId = sender.tab ? sender.tab.id : msg.tabId;
    sendToApp(msg.url, msg.quality, tabId).then(sendResponse);
    return true;
  }
  if (msg && msg.type === "status") {
    appRunning().then((running) => sendResponse({ running }));
    return true;
  }
});

// Catch file downloads started in the browser and hand them to the app (like IDM).
// Only real file links; skip blob:/data: and tiny inline things. Toggle in the popup.
const SKIP_EXT = /\.(html?|php|aspx?)($|\?)/i;

function shouldCatch(item) {
  const u = item.finalUrl || item.url || "";
  if (!/^https?:\/\//i.test(u)) return false;        // blob:, data:, file: -> leave to browser
  if (SKIP_EXT.test(u)) return false;
  // a known file type, or the server marked it as an attachment
  const name = (item.filename || "").toLowerCase();
  const known = /\.(zip|rar|7z|tar|gz|bz2|xz|iso|img|exe|msi|apk|dmg|deb|appimage|jar|pdf|docx?|xlsx?|pptx?|txt|epub|mobi|csv|mp4|mkv|webm|avi|mov|flv|m4v|wmv|mp3|m4a|aac|flac|wav|ogg|opus)($|\?)/i;
  return known.test(u) || known.test(name);
}

chrome.downloads.onCreated.addListener((item) => {
  chrome.storage.local.get({ catchDownloads: true }, async (s) => {
    if (!s.catchDownloads || !shouldCatch(item)) return;
    const url = item.finalUrl || item.url;
    const res = await sendToApp(url, "", undefined);
    if (res && res.ok) {
      // the app took it over; stop the browser's own copy
      try { chrome.downloads.cancel(item.id, () => chrome.downloads.erase({ id: item.id })); } catch (e) {}
    }
    // if the app is closed, sendToApp launched it via vdlapp:// and the browser download continues as a fallback
  });
});
