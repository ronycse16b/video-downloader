// IDM-style "Download" button over videos
(() => {
  if (window.__vdlLoaded) return;
  window.__vdlLoaded = true;

  const QUALITIES = ["Best (Video + Audio)", "1080p", "720p", "480p", "360p", "Audio only (MP3)"];
  const SITES = /(^|\.)(youtube\.com|youtu\.be|facebook\.com|fb\.watch|tiktok\.com|instagram\.com|twitter\.com|x\.com|vimeo\.com|dailymotion\.com|twitch\.tv|reddit\.com)$/i;

  let host = null, root = null, wrap = null, menu = null, toast = null;
  let currentVideo = null, hideTimer = null, overUI = false, lastMove = 0;

  function buildUI() {
    host = document.createElement("div");
    host.style.cssText = "position:fixed;top:0;left:0;z-index:2147483647;display:none;";
    root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; font-family: "Segoe UI", Arial, sans-serif; }
        .wrap { position: relative; }
        .btn { display:flex; align-items:center; gap:6px; background:#2563eb; color:#fff; border:0;
               border-radius:6px; padding:7px 12px; font-size:13px; font-weight:600; cursor:pointer;
               box-shadow:0 2px 8px rgba(0,0,0,.35); white-space:nowrap; }
        .btn:hover { filter:brightness(.92); }
        .menu { position:absolute; top:calc(100% + 4px); right:0; background:#fff; border-radius:6px;
                box-shadow:0 4px 16px rgba(0,0,0,.35); overflow:hidden; min-width:190px; }
        .menu[hidden] { display:none; }
        .item { display:block; width:100%; text-align:left; padding:8px 12px; border:0; background:#fff;
                color:#1a1a1a; font-size:13px; cursor:pointer; }
        .item:hover { background:#e8f1fc; }
        .head { padding:6px 12px; font-size:11px; color:#666; background:#f4f6f8; }
        .credit { padding:5px 12px; font-size:10px; color:#94a3b8; border-top:1px solid #eef2f7; text-align:center; }
        .toast { position:absolute; top:calc(100% + 4px); right:0; background:#1f2937; color:#fff;
                 padding:8px 12px; border-radius:6px; font-size:12px; white-space:nowrap;
                 box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .toast[hidden] { display:none; }
      </style>
      <div class="wrap">
        <button class="btn" title="Download with Video Downloader"><span>⬇</span><span>Download</span><span style="opacity:.8">▾</span></button>
        <div class="menu" hidden>
          <div class="head">Choose quality</div>
          ${QUALITIES.map((q, i) => `<button class="item" data-i="${i}">${q}</button>`).join("")}
          <div class="credit">by Refayet Rony &middot; BSc in CSE</div>
        </div>
        <div class="toast" hidden></div>
      </div>`;
    wrap = root.querySelector(".wrap");
    menu = root.querySelector(".menu");
    toast = root.querySelector(".toast");

    root.querySelector(".btn").addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      toast.hidden = true;
      menu.hidden = !menu.hidden;
    });
    menu.addEventListener("click", (e) => {
      const b = e.target.closest(".item");
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      menu.hidden = true;
      send(QUALITIES[Number(b.dataset.i)]);
    });
    host.addEventListener("mouseenter", () => { overUI = true; clearTimeout(hideTimer); });
    host.addEventListener("mouseleave", () => { overUI = false; scheduleHide(); });
    (document.documentElement || document.body).appendChild(host);
  }

  function showToast(text, ms) {
    toast.textContent = text;
    toast.hidden = false;
    setTimeout(() => { toast.hidden = true; }, ms || 3000);
  }

  function absUrl(href) {
    try { return new URL(href, location.href).href; } catch (e) { return ""; }
  }

  // which link to send to the app
  function videoUrl(v) {
    const h = location.hostname;
    if (/youtube\.com$/i.test(h) && !/^\/(watch|shorts|live)/.test(location.pathname)) {
      // preview on home/search pages: use the nearby video link
      const card = v.closest("ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer");
      const a = v.closest('a[href*="/watch"], a[href*="/shorts/"]') ||
        (card && card.querySelector('a[href*="/watch"], a[href*="/shorts/"]'));
      if (a) return absUrl(a.getAttribute("href"));
    }
    if (SITES.test(h)) return location.href;
    const src = v.currentSrc || v.src || "";
    if (/^https?:/i.test(src)) return src;
    return location.href;
  }

  function send(quality) {
    const url = currentVideo ? videoUrl(currentVideo) : location.href;
    showToast("Sending to Video Downloader...", 8000);
    try {
      chrome.runtime.sendMessage({ type: "download", url, quality }, (res) => {
        if (chrome.runtime.lastError || !res) {
          showToast("Please refresh this page", 4000);
          return;
        }
        if (res.ok) showToast(res.launched ? "Opening Video Downloader... ✔" : "Download started ✔", 3000);
        else showToast(res.error || "Failed", 4000);
      });
    } catch (e) {
      showToast("Please refresh the page and try again", 4000);
    }
  }

  function place(v) {
    const r = v.getBoundingClientRect();
    if (!host) buildUI();
    host.style.display = "block";
    const w = wrap.offsetWidth || 130;
    const top = Math.max(4, r.top + 10);
    const left = Math.max(4, Math.min(window.innerWidth - w - 8, r.right - w - 10));
    host.style.top = top + "px";
    host.style.left = left + "px";
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      if (overUI || !host) return;
      if (menu && !menu.hidden) return;
      host.style.display = "none";
      currentVideo = null;
    }, 1800);
  }

  function videoAt(x, y) {
    let best = null, bestArea = 0;
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < 160 || r.height < 90) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) {
        const area = r.width * r.height;
        if (area > bestArea) { best = v; bestArea = area; }
      }
    }
    return best;
  }

  document.addEventListener("mousemove", (e) => {
    const now = Date.now();
    if (now - lastMove < 120) return;
    lastMove = now;
    if (overUI) return;
    const v = videoAt(e.clientX, e.clientY);
    if (v) {
      if (v !== currentVideo && menu) menu.hidden = true;
      currentVideo = v;
      clearTimeout(hideTimer);
      place(v);
    } else if (host && host.style.display !== "none") {
      scheduleHide();
    }
  }, { passive: true });

  window.addEventListener("scroll", () => {
    if (currentVideo && host && host.style.display !== "none") place(currentVideo);
  }, { passive: true });

  document.addEventListener("click", (e) => {
    if (menu && !menu.hidden && !e.composedPath().includes(host)) menu.hidden = true;
  }, true);
})();
